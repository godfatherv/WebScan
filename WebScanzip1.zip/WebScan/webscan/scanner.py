below is the code tell me what need to change and give full code for above error dont change code or nature of it now give full code
# webscan/webscan/scanner.py 
# -*- coding: utf-8 -*-

import requests
import socket
import sys
import signal
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.parse import urljoin
from webscan.utils import submit_form
from webscan.payloads import ALL_PAYLOADS

# === New: Playwright dependencies ===
from playwright.sync_api import sync_playwright

# === Graceful Ctrl+C Handler ===
def _handle_exit(signum, frame):
    print("\n\n🛑 Scan aborted by user (Ctrl+C). Exiting cleanly...")
    sys.exit(0)

signal.signal(signal.SIGINT, _handle_exit)

# Shared session for all requests (reuses TCP connections)
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": "WebScanAgent/1.0"})
ADAPTER = requests.adapters.HTTPAdapter(pool_connections=50, max_retries=1)
SESSION.mount("http://", ADAPTER)
SESSION.mount("https://", ADAPTER)

def _extract_evidence(response_text, payload):
    """Extracts payload-specific snippet from HTML."""
    snippet_index = response_text.lower().find(payload.lower())
    if snippet_index != -1:
        start = max(0, snippet_index - 150)
        end = min(len(response_text), snippet_index + len(payload) + 150)
        return response_text[start:end]
    return response_text[:500]

def _save_temp_html_for_screenshot(html_content, payload, temp_dir):
    """
    Save the HTML content to a temp file wrapping it in a minimal page
    that highlights the payload string with a yellow background.
    """
    os.makedirs(temp_dir, exist_ok=True)
    safe_timestamp = int(time.time() * 1000)
    temp_file = os.path.join(temp_dir, f"{safe_timestamp}.html")

    # Escape payload for JS regex, simple approach
    import re
    escaped_payload = re.escape(payload)

    # Minimal HTML wrapper that highlights the payload occurrences
    html_template = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Vulnerability Evidence</title>
<style>
.highlight {{
    background-color: yellow;
    font-weight: bold;
}}
body {{
    margin: 10px;
    font-family: monospace, monospace;
    white-space: pre-wrap;
}}
</style>
</head>
<body>
<script>
// Highlight all occurrences of the payload text
function highlightPayload(text) {{
    if (!text) return;
    const regex = new RegExp(text, "gi");
    document.body.innerHTML = document.body.innerHTML.replace(regex, match => `<span class="highlight">${{match}}</span>`);
}}
window.onload = function() {{
    highlightPayload("{escaped_payload}");
}};
</script>
{html_content}
</body>
</html>"""

    with open(temp_file, "w", encoding="utf-8") as f:
        f.write(html_template)

    return temp_file

# === Enhanced Capture screenshot with Playwright ===
def _capture_screenshot(url, html_content=None, payload=None, screenshot_dir=None, temp_dir=None):
    """
    If html_content is provided (POST/form scenario), save and load it locally
    with highlighted payload, then screenshot.
    Otherwise, navigate directly to url (GET scenario).
    """
    if not screenshot_dir:
        return None

    os.makedirs(screenshot_dir, exist_ok=True)
    filename = os.path.join(screenshot_dir, f"{int(time.time()*1000)}.png")

    try:
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            page = browser.new_page()
            page.set_default_navigation_timeout(10000)

            if html_content and payload and temp_dir:
                # Save local HTML and load it with highlight
                local_file = _save_temp_html_for_screenshot(html_content, payload, temp_dir=temp_dir)
                page.goto(f"file://{os.path.abspath(local_file)}")
                # Wait for rendering/highlighting
                time.sleep(1)
            else:
                # Normal GET URL screenshot
                page.goto(url)
                time.sleep(1)

            page.screenshot(path=filename, full_page=True)
            browser.close()

        return filename
    except Exception as e:
        print(f"[!] Screenshot failed for {url if url else 'local file'}: {e}")
        return None

def test_payload_in_url(url, payload_list, vuln_type, report=None, seen_vulns=None):
    """Test payloads in GET parameters."""
    for payload in payload_list:
        test_url = f"{url}?test={payload}"
        try:
            response = SESSION.get(test_url, timeout=3)
            if response and payload.lower() in response.text.lower():
                vuln_key = (test_url, vuln_type, payload)
                if vuln_key not in seen_vulns:
                    seen_vulns.add(vuln_key)
                    print(f"[{vuln_type}] URL vulnerable: {test_url}")
                    evidence = _extract_evidence(response.text, payload)
                    screenshot_path = None
                    if report:
                        screenshot_path = _capture_screenshot(
                            test_url,
                            output_dir=None,
                            screenshot_dir=report.screenshot_dir,
                            temp_dir=None
                        )
                        report.log_vulnerability({
                            "type": vuln_type,
                            "url": test_url,
                            "payload": payload,
                            "method": "GET",
                            "status_code": response.status_code,
                            "headers": dict(response.headers),
                            "evidence": evidence,
                            "screenshot": screenshot_path
                        })
        except requests.RequestException:
            continue

def test_payload_in_forms(forms, payload_list, vuln_type, report=None, seen_vulns=None):
    """Test payloads in HTML forms."""
    for form in forms:
        action_url = urljoin(form["url"], form.get("action", ""))
        for payload in payload_list:
            try:
                response = submit_form(form, action_url, payload)
                if not response or not hasattr(response, "text"):
                    continue

                if payload.lower() in response.text.lower():
                    vuln_key = (action_url, vuln_type, payload)
                    if vuln_key not in seen_vulns:
                        seen_vulns.add(vuln_key)
                        print(f"[{vuln_type}] Form vulnerable at: {action_url}")
                        evidence = _extract_evidence(response.text, payload)
                        screenshot_path = None
                        if report:
                            screenshot_path = _capture_screenshot(
                                url=None,
                                html_content=response.text,
                                payload=payload,
                                screenshot_dir=report.screenshot_dir,
                                temp_dir=report.tmphtml_dir
                            )
                            report.log_vulnerability({
                                "type": vuln_type,
                                "url": action_url,
                                "payload": payload,
                                "method": form.get("method", "GET").upper(),
                                "action": form.get("action", ""),
                                "status_code": response.status_code,
                                "headers": dict(response.headers),
                                "evidence": evidence,
                                "screenshot": screenshot_path
                            })
                    break
            except requests.RequestException:
                continue

# ======== FAST MULTI-THREADED PORT SCAN =========
def _scan_single_port(host, port, timeout=0.5):
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.settimeout(timeout)
        if sock.connect_ex((host, port)) == 0:
            try:
                service = socket.getservbyport(port)
            except OSError:
                service = "unknown"
            sock.close()
            return {"port": port, "service": service}
        sock.close()
    except Exception:
        pass
    return None

def scan_open_ports(host, port_range=(1, 65535), timeout=0.5, report=None, max_threads=200):
    open_ports = []
    with ThreadPoolExecutor(max_threads) as executor:
        futures = {executor.submit(_scan_single_port, host, port, timeout): port for port in range(port_range[0], port_range[1] + 1)}
        for future in as_completed(futures):
            result = future.result()
            if result:
                open_ports.append(result)

    if open_ports and report:
        report.log_info("Open Ports", open_ports)

    return sorted(open_ports, key=lambda x: x["port"])

# ======== MAIN SCANNER =========
def run_scanner(target, links, forms, payloads, report=None, port_range=(1, 65535)):
    print(f"\n🚀 Starting Vulnerability Scan on: {target}\n")
    tested = set()
    seen_vulns = set()

    try:
        # Multi-threaded URL payload testing
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = []
            for link in links:
                if link not in tested:
                    tested.add(link)
                    for vuln_type, payload_list in payloads.items():
                        futures.append(executor.submit(test_payload_in_url, link, payload_list, vuln_type.upper(), report, seen_vulns))
            for _ in as_completed(futures):
                pass

        # Multi-threaded Form payload testing
        with ThreadPoolExecutor(max_workers=20) as executor:
            futures = []
            for vuln_type, payload_list in payloads.items():
                futures.append(executor.submit(test_payload_in_forms, forms, payload_list, vuln_type.upper(), report, seen_vulns))
            for _ in as_completed(futures):
                pass

        # Fast Port scanning
        print("\n🌐 Starting Fast Port Scan...")
        try:
            ip = socket.gethostbyname(target.replace("http://", "").replace("https://", "").split("/")[0])
            open_ports = scan_open_ports(ip, port_range=port_range, timeout=0.5, report=report, max_threads=300)
            if open_ports:
                print(f"🔓 Open Ports found on {ip}:")
                for p in open_ports:
                    print(f"  - Port {p['port']} ({p['service']})")
            else:
                print("❌ No open ports detected.")
        except socket.gaierror:
            print("[!] Could not resolve hostname for port scanning.")

    except KeyboardInterrupt:
        _handle_exit(None, None)
