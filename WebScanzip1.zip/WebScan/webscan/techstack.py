#techstackpy

import requests
from bs4 import BeautifulSoup
import re

def detect_technologies(url):
    tech_info = {
        "Headers": {},
        "Cookies": [],
        "Meta": {},
        "CMS": None,
        "Frontend": [],
        "Backend": [],
        "CDN": [],
        "Analytics": [],
        #"Raw": [],
    }

    try:
        response = requests.get(url, timeout=10, headers={"User-Agent": "WebScan v2.0"})
        headers = response.headers
        html = response.text

        tech_info["Headers"] = dict(headers)
        #tech_info["Raw"].append(dict(headers))

        # --- Backend Detection via Headers ---
        x_powered = headers.get("X-Powered-By", "").lower()
        server = headers.get("Server", "").lower()
        if "php" in x_powered: tech_info["Backend"].append("PHP")
        if "asp" in x_powered: tech_info["Backend"].append("ASP.NET")
        if "nginx" in server: tech_info["Backend"].append("Nginx")
        if "apache" in server: tech_info["Backend"].append("Apache")
        if "iis" in server: tech_info["Backend"].append("IIS")

        # --- CDN / Analytics Detection ---
        if "cloudflare" in server:
            tech_info["CDN"].append("Cloudflare")
        if "akamai" in server:
            tech_info["CDN"].append("Akamai")
        if "google-analytics.com" in html:
            tech_info["Analytics"].append("Google Analytics")

        # --- CMS Detection ---
        if re.search(r'wp-content|wordpress|wp-json', html, re.I):
            tech_info["CMS"] = "WordPress"
        elif re.search(r'drupal.js', html, re.I):
            tech_info["CMS"] = "Drupal"
        elif re.search(r'joomla.js|joomla', html, re.I):
            tech_info["CMS"] = "Joomla"
        elif re.search(r'Magento', html, re.I):
            tech_info["CMS"] = "Magento"
        elif re.search(r'Shopify.theme', html, re.I):
            tech_info["CMS"] = "Shopify"

        # --- Cookie Inspection ---
        cookies = headers.get("Set-Cookie", "")
        tech_info["Cookies"].append(cookies)
        if "wordpress" in cookies.lower():
            tech_info["CMS"] = "WordPress"

        # --- Meta Tags ---
        soup = BeautifulSoup(html, "html.parser")
        for meta in soup.find_all("meta"):
            name = meta.get("name", "").lower()
            content = meta.get("content", "")
            if "generator" in name:
                tech_info["Meta"]["Generator"] = content

        # --- Frontend JS Frameworks ---
        js_libraries = {
            "React": r"react",
            "Angular": r"angular",
            "Vue": r"vue",
            "jQuery": r"jquery",
            "Bootstrap": r"bootstrap",
        }
        for lib, pattern in js_libraries.items():
            if re.search(pattern, html, re.I):
                tech_info["Frontend"].append(lib)

    except Exception as e:
        print(f"[!] Tech detection failed for {url}: {e}")
        tech_info["Error"] = str(e)

    return tech_info
