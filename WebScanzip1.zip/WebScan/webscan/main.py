# -*- coding: utf-8 -*-
# webscan/webscan/main.py

def main():
    import argparse
    from webscan.recon import run_recon
    from webscan.crawler import run_crawler
    from webscan.scanner import run_scanner
    from webscan.report import Report
    from webscan.utils import display_banner
    from webscan.payloads import get_all_payloads
    from webscan.techstack import detect_technologies

    parser = argparse.ArgumentParser(
        description="🛡️ WebScan - Advanced Website Vulnerability & Port Scanner"
    )
    parser.add_argument("--full", action="store_true", help="Enable deep scan (LFI, SSRF, etc.)")
    parser.add_argument("--url", help="Target website URL", required=True)
    parser.add_argument("--depth", type=int, help="Crawler depth (default: 2)", default=2)
    parser.add_argument("--techstack", action="store_true", help="Detect website technology stack")
    parser.add_argument("--ports", type=str, default="1-1024", help="Port scan range (e.g., 1-65535)")

    args = parser.parse_args()

    # Step 0: Banner
    display_banner()

    target = args.url.strip()
    print(f"\n🔍 Starting scan on: {target}")

    # Step 1: Reconnaissance (ONLY ONCE)
    print("\n[1/3] 📡 Running Reconnaissance...")
    recon_data = run_recon(target)  # Returns dict with recon results

    # Step 2: Initialize Report
    report = Report(target)

    # Step 3: Gather & log metadata using cached recon data
    #print("\n[2/4] 🗂️ Gathering Target Metadata...")
    metadata = Report.gather_target_info(target, existing_data=recon_data)

    # Step 4: Techstack detection (always add to report, even if --techstack is off)
    tech_info = detect_technologies(target)
    if tech_info and tech_info not in (metadata.get("Technology Stack"), {}):
        metadata["Technology Stack"] = tech_info

    # Log metadata into report
    for key, value in metadata.items():
        report.log_info(key, value)

    if args.techstack:
        print("\n🧠 Fingerprinting Technology Stack...")
        if tech_info:
            print("📦 Detected Technologies:")
            for k, v in tech_info.items():
                if isinstance(v, list):
                    v = ", ".join(v) if v else "None"
                elif isinstance(v, dict):
                    v = ", ".join(f"{kk}: {vv}" for kk, vv in v.items())
                print(f"  - {k}: {v}")
        else:
            print("❌ Could not detect technology stack.")

    # Step 5: Crawl site and extract forms
    print("\n[2/3] 🔗 Crawling Site & Extracting Forms...")
    links, forms = run_crawler(target, max_depth=args.depth)
    for link in links:
        report.log_page(link)
    for form in forms:
        report.log_form(form)

    # Step 6: Load payloads
    payloads = get_all_payloads()

    # Step 7: Vulnerability scanning + Port Scanning
    print("\n[3/3] 🛡️ Scanning for Vulnerabilities & Open Ports...")
    try:
        port_range = tuple(map(int, args.ports.split("-")))
    except ValueError:
        print("⚠️ Invalid port range format. Using default 1-1024.")
        port_range = (1, 65535)

    run_scanner(
        target,
        links,
        forms,
        payloads,
        report=report,
        port_range=port_range
    )

    # Step 8: Save reports (JSON + PDF)
    print("\n Saving Final Reports...")
    report.finalize()

    print(f"\n[✓] Scan complete. Reports saved in: {report.report_dir}")


if __name__ == "__main__":
    main()
