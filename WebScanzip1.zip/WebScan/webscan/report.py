# -*- coding: utf-8 -*-
# webscan/webscan/report.py

import json
import os
from datetime import datetime
from fpdf import FPDF
from termcolor import cprint
import tldextract

class Report:
    def __init__(self, target_url):
        self.pages = []
        self.forms = []
        self.vulnerabilities = []
        self.general_info = {}
        self.target_url = target_url

        extracted = tldextract.extract(target_url)
        self.domain_name = f"{extracted.domain}.{extracted.suffix}"

        # Base folder for this target's reports & evidence
        self.base_dir = os.path.join("webscan", "reports", self.domain_name)
        os.makedirs(self.base_dir, exist_ok=True)

        # Subfolders for screenshots and temp HTML evidence
        self.screenshot_dir = os.path.join(self.base_dir, "screenshots")
        os.makedirs(self.screenshot_dir, exist_ok=True)

        self.tmphtml_dir = os.path.join(self.base_dir, "tmp_html")
        os.makedirs(self.tmphtml_dir, exist_ok=True)

        # Use base_dir as report_dir to save JSON and PDF reports
        self.report_dir = self.base_dir


    @staticmethod
    def gather_target_info(url, existing_data=None):
        if existing_data and isinstance(existing_data, dict) and existing_data.get("URL"):
            return existing_data

        from webscan.recon import get_whois, get_dns_records, get_ip, get_headers
        from webscan.techstack import detect_technologies as detect_tech_stack

        whois_info = get_whois(url)
        dns_info = get_dns_records(url)
        ip_info = get_ip(url)
        tech_info = detect_tech_stack(url)
        headers = get_headers(url)

        return {
            "URL": url,
            "IP Address": ip_info,
            "DNS": dns_info,
            "WHOIS": whois_info,
            "Technology Stack": tech_info,
            "Headers": headers
        }

    @staticmethod
    def generate_vulnerability_section(scan_results):
        summary = {}
        grouped = {}
        for r in scan_results:
            summary[r["type"]] = summary.get(r["type"], 0) + 1
            grouped.setdefault(r["type"], []).append(r)
        return summary, grouped

    def log_info(self, key, value):
        self.general_info[key] = value

    def log_page(self, url):
        if url not in self.pages:
            self.pages.append(url)

    def log_form(self, form_data):
        if form_data not in self.forms:
            self.forms.append(form_data)

    def log_vulnerability(self, vuln_data):
        if vuln_data not in self.vulnerabilities:
            # Removed screenshot capture here
            self.vulnerabilities.append(vuln_data)

    def _generate_filename(self, ext):
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        return os.path.join(self.report_dir, f"{self.domain_name}_{ts}.{ext}")

    def save_json(self):
        full_report = {
            "info": self.general_info,
            "pages": self.pages,
            "forms": self.forms,
            "vulnerabilities": self.vulnerabilities
        }
        json_path = self._generate_filename("json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(full_report, f, indent=4, ensure_ascii=False)
        cprint(f" JSON Report saved to {json_path}", "green")

    def save_pdf(self):
        pdf = FPDF()
        pdf.add_page()

        logo_path = os.path.join("webscan", "assets", "logo.png")
        if os.path.exists(logo_path):
            pdf.image(logo_path, x=170, y=8, w=30)

        pdf.set_font("Arial", style="B", size=16)
        pdf.cell(0, 10, "Website Vulnerability Report", ln=1, align="C")
        pdf.ln(5)

        if self.general_info:
            pdf.set_font("Arial", style='B', size=12)
            pdf.cell(0, 10, "Target Metadata:", ln=1)
            pdf.set_font("Arial", size=10)
            for key, value in self.general_info.items():
                if key == "Open Ports":
                    continue
                if isinstance(value, dict):
                    for k, v in value.items():
                        if isinstance(v, list):
                            pdf.multi_cell(0, 6, f"{k}: {', '.join(map(str, v)) if v else 'None'}")
                        else:
                            pdf.multi_cell(0, 6, f"{k}: {v if v else 'None'}")
                elif isinstance(value, list):
                    pdf.multi_cell(0, 6, f"{key}: {', '.join(map(str, value)) if value else 'None'}")
                else:
                    pdf.multi_cell(0, 6, f"{key}: {value}")
            pdf.ln(4)

        if "Open Ports" in self.general_info and self.general_info["Open Ports"]:
            pdf.set_font("Arial", style='B', size=12)
            pdf.cell(0, 10, "Open Ports:", ln=1)
            pdf.set_font("Arial", size=10)
            pdf.set_fill_color(200, 200, 200)
            pdf.cell(30, 8, "Port", border=1, align="C", fill=True)
            pdf.cell(80, 8, "Service", border=1, align="C", fill=True)
            pdf.cell(30, 8, "Status", border=1, align="C", fill=True)
            pdf.ln()

            for port_info in self.general_info["Open Ports"]:
                pdf.cell(30, 8, str(port_info.get("port", "")), border=1, align="C")
                pdf.cell(80, 8, str(port_info.get("service", "")), border=1, align="C")
                pdf.cell(30, 8, "open", border=1, align="C")
                pdf.ln()
            pdf.ln(4)

        pdf.set_font("Arial", style='B', size=12)
        pdf.cell(0, 10, f"Crawled Pages ({len(self.pages)}):", ln=1)
        pdf.set_font("Arial", size=9)
        for url in self.pages:
            pdf.multi_cell(0, 5, url)
        pdf.ln(4)

        pdf.set_font("Arial", style='B', size=12)
        pdf.cell(0, 10, f"Forms Found ({len(self.forms)}):", ln=1)
        pdf.set_font("Arial", size=9)
        for form in self.forms:
            pdf.multi_cell(0, 5, f"{form['url']} -> {form['action']}")
        pdf.ln(4)

        if self.vulnerabilities:
            summary, grouped_results = self.generate_vulnerability_section(self.vulnerabilities)

            pdf.set_font("Arial", style='B', size=12)
            pdf.cell(0, 10, "Vulnerability Summary:", ln=1)
            pdf.set_fill_color(220, 220, 220)
            pdf.set_font("Arial", size=10)
            pdf.cell(80, 8, "Type", border=1, align="C", fill=True)
            pdf.cell(30, 8, "Count", border=1, align="C", fill=True)
            pdf.ln()
            for k, v in summary.items():
                pdf.cell(80, 8, k, border=1, align="C")
                pdf.cell(30, 8, str(v), border=1, align="C")
                pdf.ln()
            pdf.ln(4)

            pdf.set_font("Arial", style='B', size=12)
            pdf.cell(0, 10, "Vulnerabilities Detected:", ln=1)
            for vuln_type, vulns in grouped_results.items():
                pdf.set_font("Arial", style='B', size=11)
                pdf.cell(0, 8, f"{vuln_type} Vulnerabilities:", ln=1)
                pdf.set_font("Arial", size=9)

                for vuln in vulns:
                    pdf.multi_cell(0, 5, f"URL: {vuln.get('url', '')}")
                    pdf.multi_cell(0, 5, f"Type: {vuln.get('type', '')}")
                    pdf.multi_cell(0, 5, f"Payload: {vuln.get('payload', '')}")
                    if 'evidence' in vuln and vuln['evidence']:
                        pdf.multi_cell(0, 5, f"Evidence: {vuln['evidence']}")
                    # Screenshot embedding disabled:
                    # if 'screenshot' in vuln and vuln['screenshot'] and os.path.exists(vuln['screenshot']):
                    #     pdf.ln(2)
                    #     pdf.image(vuln['screenshot'], w=100)
                    pdf.ln(4)

        pdf_path = self._generate_filename("pdf")
        pdf.output(pdf_path)
        cprint(f" PDF Report saved to {pdf_path}", "cyan")

    def finalize(self):
        self.save_json()
        self.save_pdf()
