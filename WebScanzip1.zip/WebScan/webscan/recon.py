# -*- coding: utf-8 -*-
# webscan/webscan/recon.py

import socket
import whois
import dns.resolver
import requests
import tldextract


def get_ip(domain):
    """Resolve IP address for a given domain."""
    try:
        ip = socket.gethostbyname(domain)
        print(f"[+] Resolved IP: {ip}")
        return ip
    except Exception as e:
        print(f"[!] Failed to resolve IP: {e}")
        return None


def get_whois(domain):
    """Retrieve WHOIS information."""
    try:
        w = whois.whois(domain)
        print("[+] WHOIS info retrieved.")
        return {
            "domain_name": w.domain_name,
            "registrar": w.registrar,
            "creation_date": str(w.creation_date),
            "expiration_date": str(w.expiration_date),
            "emails": w.emails
        }
    except Exception as e:
        print(f"[!] WHOIS lookup failed: {e}")
        return {}


def get_dns_records(domain):
    """Retrieve DNS records."""
    records = {}
    try:
        for record_type in ['A', 'AAAA', 'MX', 'NS']:
            try:
                answers = dns.resolver.resolve(domain, record_type)
                records[record_type] = [r.to_text() for r in answers]
            except Exception as sub_err:
                records[record_type] = []
                print(f"[!] DNS lookup failed for {record_type}: {sub_err}")
        if any(records.values()):
            print("[+] DNS records found.")
    except Exception as e:
        print(f"[!] DNS lookup failed: {e}")
    return records


def get_headers(url):
    """Retrieve HTTP headers from a URL."""
    try:
        res = requests.get(url, timeout=10)
        headers = dict(res.headers)
        print(f"[+] Retrieved HTTP headers.")
        return headers
    except Exception as e:
        print(f"[!] Failed to fetch headers: {e}")
        return {}


def run_recon(url):
    """
    Runs reconnaissance once and returns data in a reusable format.
    This format matches the expectations of Report.gather_target_info()
    so no extra lookups are needed later.
    """
    print("\n[***] Running Reconnaissance Phase")

    # Extract clean domain from URL
    extracted = tldextract.extract(url)
    domain = ".".join(part for part in [extracted.domain, extracted.suffix] if part)

    ip_info = get_ip(domain)
    whois_info = get_whois(domain)
    dns_info = get_dns_records(domain)
    headers_info = get_headers(url)

    # Return in standardized format
    return {
        "URL": url,
        "IP Address": ip_info,
        "DNS": dns_info,
        "WHOIS": whois_info,
        "Technology Stack": {},  # tech stack will be filled later if enabled
        "Headers": headers_info
    }


if __name__ == "__main__":
    url = input("Enter URL to run recon (e.g., https://testphp.vulnweb.com): ").strip()
    results = run_recon(url)
    print("\nRecon Results:\n", results)
