# utils.py
# -*- coding: utf-8 -*-

import requests
from bs4 import BeautifulSoup
from urllib.parse import urljoin, urlparse
import re
import logging
import warnings
from bs4 import MarkupResemblesLocatorWarning
warnings.filterwarnings("ignore", category=MarkupResemblesLocatorWarning)


def display_banner():
    print("""
\033[1;92m+------------------+     🛡️  \033[4m𝗪𝗘𝗕𝗦𝗖𝗔𝗡 - 𝗪𝗲𝗯𝘀𝗶𝘁𝗲 𝗩𝘂𝗹𝗻𝗲𝗿𝗮𝗯𝗶𝗹𝗶𝘁𝘆 𝗦𝗰𝗮𝗻𝗻𝗲𝗿\033[0m
\033[1;92m|     WebScan      |     👤  \033[1;92m\033[4m𝗔𝘂𝘁𝗵𝗼𝗿: 𝗦𝗮𝗴𝗮𝗿 𝗠𝗮𝗻𝗲\033[0m
\033[1;92m+------------------+\033[0m
""")

# ===================== Logging Setup =====================
logging.basicConfig(
    level=logging.INFO,
    format='[%(asctime)s] [%(levelname)s] %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# ===================== HTTP Request Wrapper =====================
def safe_get(url, timeout=10, headers=None):
    """
    Sends a GET request with basic error handling.
    """
    try:
        response = requests.get(url, timeout=timeout, headers=headers or default_headers())
        response.raise_for_status()
        return response
    except requests.RequestException as e:
        logging.warning(f"GET request failed for {url} — {e}")
        return None

def safe_post(url, data=None, headers=None, timeout=10):
    """
    Sends a POST request with error handling.
    """
    try:
        response = requests.post(url, data=data, headers=headers or default_headers(), timeout=timeout)
        response.raise_for_status()
        return response
    except requests.RequestException as e:
        logging.warning(f"POST request failed for {url} — {e}")
        return None

# ===================== Header Generator =====================
def default_headers():
    return {
        "User-Agent": "Mozilla/5.0 (compatible; WebScanBot/1.0; +https://example.com/bot)"
    }

# ===================== URL Normalizer =====================
def normalize_url(base_url, link):
    """
    Resolves a relative URL to an absolute URL.
    """
    return urljoin(base_url, link)

# ===================== Domain Matcher =====================
def is_same_domain(base_url, link):
    """
    Checks if a link belongs to the same domain as the base URL.
    """
    return urlparse(base_url).netloc == urlparse(link).netloc

# ===================== HTML Form Extractor =====================
def extract_forms(html_content):
    """
    Extracts forms from HTML content using BeautifulSoup.
    """
    soup = BeautifulSoup(html_content, "html.parser")
    return soup.find_all("form")

# ===================== Input Field Parser =====================
def extract_inputs(form):
    """
    Extracts input fields and default values from a form tag.
    """
    inputs = []
    for input_tag in form.find_all("input"):
        name = input_tag.get("name")
        value = input_tag.get("value", "")
        input_type = input_tag.get("type", "text")
        if name:
            inputs.append({"name": name, "value": value, "type": input_type})
    return inputs

# ===================== Form Details Parser =====================
def get_form_details(form, base_url):
    """
    Parses form tag to extract method, action, and inputs.
    """
    action = form.get("action")
    method = form.get("method", "get").lower()
    action_url = normalize_url(base_url, action)
    inputs = extract_inputs(form)
    return {
        "method": method,
        "action": action_url,
        "inputs": inputs
    }

# ===================== Link Extractor =====================
def extract_links(html_content, base_url):
    """
    Extracts and normalizes all href links from a page.
    """
    soup = BeautifulSoup(html_content, "html.parser")
    links = set()
    for tag in soup.find_all("a", href=True):
        href = tag.get("href")
        url = normalize_url(base_url, href)
        if url.startswith("http") and is_same_domain(base_url, url):
            links.add(url)
    return list(links)

# ===================== Payload Injection Helper =====================
def inject_payload(data_dict, payload):
    """
    Injects payload into each form input (for scanning).
    """
    return {key: payload if val["type"] != "submit" else val["value"]
            for key, val in data_dict.items()}

# ===================== Vulnerability Reporter =====================
def log_vulnerability(vuln_type, location, payload):
    """
    Logs a found vulnerability in a standard format.
    """
    logging.warning(f"[VULNERABILITY] Type: {vuln_type} | Location: {location} | Payload: {payload}")
    return {
        "type": vuln_type,
        "location": location,
        "payload": payload
    }
# ===================== Form Submitter =====================
def submit_form(form_details, url, payload):
    """
    Submits the form with injected payload into all input fields.
    """
    data = {}
    for input_field in form_details["inputs"]:
        if input_field["type"] == "submit":
            continue
        data[input_field["name"]] = payload

    if form_details["method"] == "post":
        return safe_post(form_details["action"], data=data)
    else:
        return safe_get(form_details["action"], headers=default_headers()
   )

