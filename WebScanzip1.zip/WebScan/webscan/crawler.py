# -*- coding: utf-8 -*- crawler.py

import requests
from bs4 import BeautifulSoup
from bs4 import XMLParsedAsHTMLWarning
import warnings
warnings.filterwarnings("ignore", category=XMLParsedAsHTMLWarning)
from urllib.parse import urljoin, urlparse, urlunparse, parse_qsl, urlencode
import tldextract
from webscan.payloads import ALL_PAYLOADS
import re
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, as_completed

# Store visited links in normalized form
visited_links = set()
session = requests.Session()
session.headers.update({"User-Agent": "WebScanAgent/1.0"})

# --- URL Normalization ---
def normalize_url(url):
    parsed = urlparse(url)
    scheme = parsed.scheme.lower()
    netloc = parsed.netloc.lower()
    if netloc.startswith("www."):
        netloc = netloc[4:]
    path = parsed.path if parsed.path == "/" else parsed.path.rstrip("/")
    query_params = sorted(parse_qsl(parsed.query))
    query = urlencode(query_params)
    fragment = ""
    return urlunparse((scheme, netloc, path, "", query, fragment))

def add_url_if_new(url):
    norm = normalize_url(url)
    if norm not in visited_links:
        visited_links.add(norm)
        return True
    return False

def parse_robots_txt(url):
    print("[*] Checking robots.txt")
    disallowed = []
    try:
        res = session.get(urljoin(url, "/robots.txt"), timeout=8)
        if res.status_code == 200:
            for line in res.text.splitlines():
                if line.lower().startswith("disallow:"):
                    path = line.split(":", 1)[1].strip()
                    if path and path != "/":
                        full_url = urljoin(url, path)
                        if add_url_if_new(full_url):
                            disallowed.append(full_url)
    except Exception as e:
        print(f"[!] robots.txt error: {e}")
    return disallowed

def parse_sitemap(url):
    print("[*] Checking sitemap.xml")
    sitemap_urls = []
    try:
        res = session.get(urljoin(url, "/sitemap.xml"), timeout=8)
        if res.status_code == 200:
            tree = ET.fromstring(res.text)
            for loc in tree.findall(".//{*}loc"):
                full_url = loc.text
                if add_url_if_new(full_url):
                    sitemap_urls.append(full_url)
    except Exception as e:
        print(f"[!] sitemap.xml error: {e}")
    return sitemap_urls

def is_internal_url(url, base_domain):
    parsed = urlparse(url)
    return parsed.netloc == "" or base_domain in parsed.netloc

def extract_links_from_js(js_content, base_url):
    links = set()
    url_patterns = re.findall(r'["\'](\/[a-zA-Z0-9_\-\/\.\?\=\&]+)["\']', js_content)
    for path in url_patterns:
        full_url = urljoin(base_url, path)
        if add_url_if_new(full_url):
            links.add(full_url)
    return links

def extract_links(url, html, base_domain):
    soup = BeautifulSoup(html, "html.parser")
    links = []
    for tag in soup.find_all("a", href=True):
        href = tag['href']
        full_url = urljoin(url, href)
        if is_internal_url(full_url, base_domain):
            clean_url = full_url.split('#')[0]
            if add_url_if_new(clean_url):
                links.append(normalize_url(clean_url))
    return links

def extract_forms(url, html):
    soup = BeautifulSoup(html, "html.parser")
    forms = []
    for form in soup.find_all("form"):
        action = form.get("action")
        method = form.get("method", "get").lower()
        inputs = []
        for inp in form.find_all("input"):
            input_type = inp.get("type", "text")
            input_name = inp.get("name")
            inputs.append({"type": input_type, "name": input_name})
        forms.append({
            "url": normalize_url(url),
            "action": normalize_url(urljoin(url, action)),
            "method": method,
            "inputs": inputs
        })
    return forms

def test_payloads_on_url(url):
    for vuln_type, payloads in ALL_PAYLOADS.items():
        print(f"\n[!] Testing {vuln_type} on {url}")
        for payload in payloads:
            try:
                test_url = f"{url}?test={payload}"
                res = session.get(test_url, timeout=8)
                if payload in res.text:
                    print(f"[!!] {vuln_type} Found on {url} with payload: {payload}")
                    break
            except Exception as e:
                print(f"[x] Error testing {vuln_type} payload: {payload} => {e}")

def submit_form(form, url, payload):
    target_url = form["action"]
    method = form["method"]
    data = {}
    for input_field in form["inputs"]:
        input_name = input_field.get("name")
        if input_name:
            data[input_name] = payload
    if method == "post":
        return session.post(target_url, data=data, timeout=8)
    else:
        return session.get(target_url, params=data, timeout=8)

def test_payload_in_forms(forms, payload_list, vuln_type):
    for form in forms:
        for payload in payload_list:
            try:
                response = submit_form(form, form["url"], payload)
                if payload.lower() in response.text.lower():
                    print(f"[{vuln_type}] Form vulnerable at: {form['url']}")
                    break
            except requests.RequestException:
                continue

def crawl_single_url(current_url, depth, base_domain, max_depth):
    found_links = []
    found_forms = []
    if depth > max_depth:
        return found_links, found_forms
    try:
        res = session.get(current_url, timeout=8)
        found_links.append(current_url)
        print(f"[+] Crawled: {current_url}")

        new_links = extract_links(current_url, res.text, base_domain)
        for link in new_links:
            found_links.append((link, depth + 1))

        forms = extract_forms(current_url, res.text)
        found_forms.extend(forms)

        soup = BeautifulSoup(res.text, "html.parser")
        for tag in soup.find_all("script", src=True):
            js_url = urljoin(current_url, tag['src'])
            if add_url_if_new(js_url):
                try:
                    js_resp = session.get(js_url, timeout=5)
                    if js_resp.status_code == 200 and 'text/javascript' in js_resp.headers.get('Content-Type', ''):
                        js_links = extract_links_from_js(js_resp.text, current_url)
                        for link in js_links:
                            found_links.append((link, depth + 1))
                except Exception:
                    pass
    except Exception as e:
        print(f"[!] Failed to crawl {current_url}: {e}")
    return found_links, found_forms

def run_crawler(base_url, max_depth=2):
    print("\n[***] Crawling Website")
    extracted = tldextract.extract(base_url)
    base_domain = ".".join(part for part in [extracted.domain, extracted.suffix] if part)
    to_visit = [(normalize_url(base_url), 0)]

    robots_links = parse_robots_txt(base_url)
    sitemap_links = parse_sitemap(base_url)
    to_visit.extend((link, 1) for link in robots_links + sitemap_links)

    all_links = []
    all_forms = []

    with ThreadPoolExecutor(max_workers=10) as executor:
        while to_visit:
            futures = []
            for url, depth in list(to_visit):
                to_visit.remove((url, depth))
                futures.append(executor.submit(crawl_single_url, url, depth, base_domain, max_depth))

            for future in as_completed(futures):
                new_links, new_forms = future.result()
                for item in new_links:
                    if isinstance(item, tuple):
                        to_visit.append(item)
                    else:
                        all_links.append(item)
                all_forms.extend(new_forms)

    return all_links, all_forms

def run_scan(base_url):
    links, forms = run_crawler(base_url)
    print("\n[***] Starting URL-based Payload Testing")
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = [executor.submit(test_payloads_on_url, link) for link in links]
        for _ in as_completed(futures):
            pass
    print("\n[***] Starting Form-based Payload Testing")
    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = []
        for vuln_type, payloads in ALL_PAYLOADS.items():
            futures.append(executor.submit(test_payload_in_forms, forms, payloads, vuln_type))
        for _ in as_completed(futures):
            pass

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="WebScan - Web Vulnerability Scanner")
    parser.add_argument("--url", required=True, help="Target URL to scan")
    parser.add_argument("--depth", type=int, default=2, help="Maximum crawl depth")
    args = parser.parse_args()
    run_scan(args.url)
