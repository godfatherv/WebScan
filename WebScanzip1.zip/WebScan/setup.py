from setuptools import setup, find_packages

setup(
    name='webscan',
    version='1.1',
    description='Advanced Website Vulnerability Scanner',
    author='MSB',
    packages=find_packages(),
    install_requires=[
        "requests",
        "beautifulsoup4",
        "termcolor",
        "fpdf",
        "colorama",
        "tldextract",
        "urllib3",
        "aiohttp",
        "lxml",
        "python-whois",
        "dnspython",
        "ipwhois",
        "PyPDF2",
        "reportlab",
        "jsbeautifier",
        "builtwith",
        "pillow",         # image processing for red highlight
        "playwright",     # for browser automation without Chrome install
    ],
    entry_points={
        'console_scripts': [
            'webscan = webscan.main:main'
        ],
    },
    include_package_data=True,
    python_requires='>=3.7',
)
